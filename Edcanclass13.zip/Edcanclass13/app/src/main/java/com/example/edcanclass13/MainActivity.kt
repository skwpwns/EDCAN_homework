package com.example.edcanclass13

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var bnv_main = findViewById(R.id.bnv_main) as BottomNavigationView
        bnv_main.run {
            setOnNavigationItemSelectedListener {
                when (it.itemId) {
                    R.id.menu_main_home -> { // 다른 프래그먼트 화면으로 이동하는 기능
                        val BlankFragment1 = Fragment1()
                        supportFragmentManager.beginTransaction()
                            .replace(R.id.fl_con, BlankFragment1).commit()
                    }
                    R.id.menu_main_search -> { // 다른 프래그먼트 화면으로 이동하는 기능
                        val BlankFragment1 = Fragment2()
                        supportFragmentManager.beginTransaction()
                            .replace(R.id.fl_con, BlankFragment1).commit()
                    }
                    R.id.menu_main_plus -> { // 다른 프래그먼트 화면으로 이동하는 기능
                        val BlankFragment1 = Fragment3()
                        supportFragmentManager.beginTransaction()
                            .replace(R.id.fl_con, BlankFragment1).commit()
                    }
                    R.id.menu_main_menu -> { // 다른 프래그먼트 화면으로 이동하는 기능
                        val BlankFragment1 = Fragment4()
                        supportFragmentManager.beginTransaction()
                            .replace(R.id.fl_con, BlankFragment1).commit()
                    }
                    R.id.menu_main_my -> { // 다른 프래그먼트 화면으로 이동하는 기능
                        val BlankFragment1 = Fragment5()
                        supportFragmentManager.beginTransaction()
                            .replace(R.id.fl_con, BlankFragment1).commit()
                    }
                }
                true
            }
            selectedItemId = R.id.menu_main_home
        }

//        var bnv_main = findViewById(R.id.bnv_main) as BottomNavigationView
//
//        bnv_main.run {
//            setOnNavigationItemSelectedListener {
//                when (it.itemId) {
//                    R.id.menu_main_home -> {
//                        // 다른 프래그먼트 화면으로 이동하는 기능
//                        val BlankFragment1 = Fragment1()
//                        supportFragmentManager.beginTransaction()
//                            .replace(R.id.fl_con, BlankFragment1).commit()
//                    }
//                    R.id.menu_main_my -> {
//                        val BlankFragment2 = Fragment2()
//                        supportFragmentManager.beginTransaction()
//                            .replace(R.id.fl_con, BlankFragment2).commit()
//                    }
//                    R.id.menu_main_my -> {
//                        val BlankFragment3 = Fragment3()
//                        supportFragmentManager.beginTransaction()
//                            .replace(R.id.fl_con, BlankFragment3).commit()
//                    }
//                    R.id.menu_main_my -> {
//                        val BlankFragment4 = Fragment4()
//                        supportFragmentManager.beginTransaction()
//                            .replace(R.id.fl_con, BlankFragment4).commit()
//                    }
//                    R.id.menu_main_my -> {
//                        val BlankFragment5 = Fragment5()
//                        supportFragmentManager.beginTransaction()
//                            .replace(R.id.fl_con, BlankFragment5).commit()
//                    }
//                }
//                true
//            }
//            selectedItemId = R.id.menu_main_home
//        }
    }

    }